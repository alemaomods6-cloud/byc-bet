import { Html, Head, Main, NextScript } from 'next/document'

export default function Document() {
  return (
    <Html lang="pt-BR">
      <Head>
        <meta charSet="utf-8" />
        <meta name="theme-color" content="#0d0d0d" />
      </Head>
      <body>
        <Main />
        <NextScript />
      </body>
    </Html>
  )
}
