import { useState } from "react";
import { useRouter } from "next/router";
import Link from "next/link";
import api from "../lib/api";

export default function Register() {
  const router = useRouter();
  const { ref } = router.query;
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  const handleRegister = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await api.post("/auth/register", {
        email,
        ref: ref || null
      });

      localStorage.setItem("token", response.data.token);
      router.push("/");
    } catch (error) {
      alert("Erro ao cadastrar: " + error.response?.data?.error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-dark flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-primary mb-2">BYC.BET</h1>
          <h2 className="text-2xl font-bold">Criar Conta</h2>
        </div>

        <form onSubmit={handleRegister} className="bg-darker p-6 rounded-lg">
          <input
            type="email"
            placeholder="Digite seu email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="w-full"
          />

          {ref && (
            <div className="bg-primary bg-opacity-20 p-3 rounded mt-4 text-sm">
              <p>Você foi indicado por: <strong>{ref}</strong></p>
              <p className="text-gray-300 mt-1">Ganhe bônus ao depositar!</p>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-6"
          >
            {loading ? "Cadastrando..." : "Cadastrar"}
          </button>
        </form>

        <p className="text-center text-gray-400 mt-4">
          Já tem conta?{" "}
          <Link href="/" className="text-primary hover:text-neon">
            Faça login
          </Link>
        </p>
      </div>
    </div>
  );
}
