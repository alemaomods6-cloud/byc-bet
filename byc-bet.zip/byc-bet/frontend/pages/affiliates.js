import { useState, useEffect } from "react";
import Link from "next/link";
import api from "../lib/api";

export default function Affiliates() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAffiliateStats();
  }, []);

  const loadAffiliateStats = async () => {
    try {
      const response = await api.get("/user/referral-stats");
      setStats(response.data);
    } catch (error) {
      console.error("Erro ao carregar estatísticas:", error);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    alert("Copiado para a área de transferência!");
  };

  return (
    <div className="min-h-screen bg-dark">
      <header className="bg-darker p-4 border-b border-gray-700">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <Link href="/">
            <h1 className="text-3xl font-bold text-primary cursor-pointer">BYC.BET</h1>
          </Link>
          <Link href="/">
            <button className="bg-gray-700 hover:bg-gray-600">← Voltar</button>
          </Link>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-4 py-12">
        <h2 className="text-3xl font-bold mb-8">🔗 Programa de Afiliados</h2>

        {loading ? (
          <p className="text-center text-gray-400">Carregando...</p>
        ) : stats ? (
          <>
            {/* Ganhos */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              <div className="bg-darker p-6 rounded-lg">
                <p className="text-gray-400 mb-2">Ganhos Totais</p>
                <h3 className="text-3xl font-bold text-neon">R$ {stats.ganhosAfiliado?.toFixed(2) || "0.00"}</h3>
              </div>

              <div className="bg-darker p-6 rounded-lg">
                <p className="text-gray-400 mb-2">Indicações Ativas</p>
                <h3 className="text-3xl font-bold text-primary">{stats.referredCount || 0}</h3>
              </div>
            </div>

            {/* Código de Referência */}
            <div className="bg-darker p-6 rounded-lg mb-8">
              <h3 className="text-xl font-bold mb-4">Seu Código de Referência</h3>

              <div className="bg-primary bg-opacity-10 p-4 rounded-lg mb-4">
                <p className="text-gray-300 mb-2">Código:</p>
                <div className="flex items-center gap-2">
                  <code className="flex-1 bg-darker p-3 rounded font-mono text-neon">
                    {stats.referralCode}
                  </code>
                  <button
                    onClick={() => copyToClipboard(stats.referralCode)}
                    className="bg-primary hover:bg-purple-700"
                  >
                    Copiar
                  </button>
                </div>
              </div>

              <p className="text-gray-300 mb-2">Link de Indicação:</p>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={stats.referralLink}
                  readOnly
                  className="flex-1"
                />
                <button
                  onClick={() => copyToClipboard(stats.referralLink)}
                  className="bg-primary hover:bg-purple-700"
                >
                  Copiar
                </button>
              </div>
            </div>

            {/* Como Funciona */}
            <div className="bg-darker p-6 rounded-lg mb-8">
              <h3 className="text-xl font-bold mb-4">💡 Como Funciona</h3>
              <ul className="space-y-3 text-gray-300">
                <li className="flex items-start gap-3">
                  <span className="text-neon font-bold">1.</span>
                  <span>Compartilhe seu link de indicação com amigos</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-neon font-bold">2.</span>
                  <span>Quando alguém se cadastra usando seu link, vira seu indicado</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-neon font-bold">3.</span>
                  <span>Você ganha 5% de comissão em cada depósito que seu indicado faz</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-neon font-bold">4.</span>
                  <span>Os ganhos são creditados automaticamente na sua conta</span>
                </li>
              </ul>
            </div>

            {/* Indicações */}
            {stats.referredUsers && stats.referredUsers.length > 0 && (
              <div className="bg-darker p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-4">Seus Indicados</h3>
                <div className="space-y-3">
                  {stats.referredUsers.map((user, idx) => (
                    <div key={idx} className="border border-gray-700 p-4 rounded">
                      <p className="font-bold">{user.email}</p>
                      <p className="text-gray-400 text-sm">
                        Saldo: R$ {user.saldo?.toFixed(2) || "0.00"}
                      </p>
                      <p className="text-gray-500 text-sm">
                        Cadastrado em: {new Date(user.createdAt).toLocaleDateString("pt-BR")}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        ) : (
          <p className="text-center text-gray-400">Erro ao carregar dados</p>
        )}
      </main>
    </div>
  );
}
