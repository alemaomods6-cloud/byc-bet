import { useState, useEffect } from "react";
import Link from "next/link";
import api from "../lib/api";

export default function Home() {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Verificar se há token salvo
    const token = localStorage.getItem("token");
    if (token) {
      loadUser();
    }
  }, []);

  const loadUser = async () => {
    try {
      const response = await api.get("/user/profile");
      setUser(response.data);
    } catch (error) {
      console.error("Erro ao carregar usuário:", error);
      localStorage.removeItem("token");
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await api.post("/auth/login", { email });
      localStorage.setItem("token", response.data.token);
      setUser(response.data.user);
      setEmail("");
    } catch (error) {
      alert("Erro ao fazer login: " + error.response?.data?.error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    setUser(null);
    setEmail("");
  };

  return (
    <div className="min-h-screen bg-dark">
      {/* Header */}
      <header className="bg-darker p-4 flex justify-between items-center border-b border-gray-700">
        <h1 className="text-3xl font-bold text-primary">BYC.BET</h1>
        {user && (
          <button onClick={handleLogout} className="bg-red-600 hover:bg-red-700">
            Sair
          </button>
        )}
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto p-4">
        {!user ? (
          <section className="text-center py-20">
            <h2 className="text-4xl font-bold mb-4">Bem-vindo ao BYC.BET</h2>
            <p className="text-gray-400 mb-8">Plataforma de apostas e cassino online</p>

            <form onSubmit={handleLogin} className="max-w-md mx-auto">
              <input
                type="email"
                placeholder="Digite seu email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full"
              />
              <button
                type="submit"
                disabled={loading}
                className="w-full mt-4"
              >
                {loading ? "Entrando..." : "Entrar"}
              </button>
            </form>

            <p className="text-gray-400 mt-4">
              Não tem conta?{" "}
              <Link href="/register" className="text-primary hover:text-neon">
                Cadastre-se
              </Link>
            </p>
          </section>
        ) : (
          <section>
            {/* Banner */}
            <div className="bg-gradient-to-r from-primary to-purple-900 p-8 rounded-lg mb-8 text-center">
              <h2 className="text-3xl font-bold mb-2">Bônus de Boas-vindas!</h2>
              <p className="text-lg">Comece a jogar agora e ganhe prêmios incríveis</p>
            </div>

            {/* Saldo */}
            <div className="bg-darker p-6 rounded-lg mb-8 text-center">
              <p className="text-gray-400 mb-2">Seu Saldo</p>
              <h3 className="text-4xl font-bold text-neon">R$ {user.saldo?.toFixed(2) || "0.00"}</h3>
            </div>

            {/* Ações Rápidas */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <Link href="/deposit">
                <button className="w-full py-4 text-lg">
                  💰 Depositar
                </button>
              </Link>
              <Link href="/withdraw">
                <button className="w-full py-4 text-lg">
                  💸 Sacar
                </button>
              </Link>
              <Link href="/affiliates">
                <button className="w-full py-4 text-lg">
                  🔗 Afiliados
                </button>
              </Link>
            </div>

            {/* Jogos */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">Jogos Disponíveis</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Link href="/games/mines">
                  <div className="bg-darker p-6 rounded-lg hover:border-primary border border-gray-700 cursor-pointer transition">
                    <h3 className="text-2xl font-bold mb-2">💣 Mines</h3>
                    <p className="text-gray-400">Jogo de multiplicador com bombas</p>
                  </div>
                </Link>

                <Link href="/games/aviator">
                  <div className="bg-darker p-6 rounded-lg hover:border-primary border border-gray-700 cursor-pointer transition">
                    <h3 className="text-2xl font-bold mb-2">✈️ Aviator</h3>
                    <p className="text-gray-400">Jogo de crash com multiplicador</p>
                  </div>
                </Link>
              </div>
            </section>

            {/* Info PIX */}
            <section className="bg-darker p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Informações PIX</h3>
              <p className="mb-2">
                <strong>Chave PIX:</strong> 6021408@vakinha.com.br
              </p>
              <p>
                <strong>Recebedor:</strong> BYC LTDA
              </p>
            </section>
          </section>
        )}
      </main>
    </div>
  );
}
