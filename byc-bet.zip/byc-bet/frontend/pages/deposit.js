import { useState, useEffect } from "react";
import Link from "next/link";
import api from "../lib/api";

export default function Deposit() {
  const [valor, setValor] = useState("");
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState(null);
  const [depositInfo, setDepositInfo] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const response = await api.get("/user/profile");
      setUser(response.data);
    } catch (error) {
      console.error("Erro ao carregar usuário:", error);
    }
  };

  const handleDeposit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await api.post("/payments/deposit/request", {
        valor: parseFloat(valor)
      });

      setDepositInfo(response.data);
      setValor("");
    } catch (error) {
      alert("Erro: " + error.response?.data?.error);
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmDeposit = async () => {
    try {
      const response = await api.post("/payments/deposit/confirm", {
        depositId: depositInfo.depositId,
        valor: depositInfo.valor
      });

      alert("Depósito confirmado!");
      setDepositInfo(null);
      loadUser();
    } catch (error) {
      alert("Erro: " + error.response?.data?.error);
    }
  };

  return (
    <div className="min-h-screen bg-dark">
      <header className="bg-darker p-4 border-b border-gray-700">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <Link href="/">
            <h1 className="text-3xl font-bold text-primary cursor-pointer">BYC.BET</h1>
          </Link>
          <Link href="/">
            <button className="bg-gray-700 hover:bg-gray-600">← Voltar</button>
          </Link>
        </div>
      </header>

      <main className="max-w-2xl mx-auto p-4 py-12">
        <h2 className="text-3xl font-bold mb-8">Depositar</h2>

        {user && (
          <div className="bg-darker p-4 rounded-lg mb-8">
            <p className="text-gray-400">Saldo Atual</p>
            <h3 className="text-3xl font-bold text-neon">R$ {user.saldo?.toFixed(2) || "0.00"}</h3>
          </div>
        )}

        {!depositInfo ? (
          <form onSubmit={handleDeposit} className="bg-darker p-6 rounded-lg">
            <label className="block mb-4">
              <span className="text-gray-300 mb-2 block">Valor do Depósito (R$)</span>
              <input
                type="number"
                step="0.01"
                min="1"
                max="500"
                placeholder="Digite o valor (1 a 500)"
                value={valor}
                onChange={(e) => setValor(e.target.value)}
                required
              />
              <p className="text-gray-500 text-sm mt-2">Mínimo: R$ 1,00 | Máximo: R$ 500,00</p>
            </label>

            <button
              type="submit"
              disabled={loading}
              className="w-full"
            >
              {loading ? "Processando..." : "Solicitar Depósito"}
            </button>
          </form>
        ) : (
          <div className="bg-darker p-6 rounded-lg">
            <h3 className="text-xl font-bold mb-4">Informações do Depósito</h3>

            <div className="bg-primary bg-opacity-10 p-4 rounded-lg mb-6">
              <p className="text-gray-300 mb-2">Valor:</p>
              <p className="text-2xl font-bold text-neon mb-4">R$ {depositInfo.valor?.toFixed(2)}</p>

              <p className="text-gray-300 mb-2">Chave PIX:</p>
              <p className="font-mono bg-darker p-2 rounded mb-4 break-all">{depositInfo.pix}</p>

              <p className="text-gray-300 mb-2">Recebedor:</p>
              <p className="font-bold">{depositInfo.recebedor}</p>
            </div>

            <p className="text-gray-400 mb-6">
              Após transferir via PIX, clique no botão abaixo para confirmar o depósito.
            </p>

            <div className="flex gap-4">
              <button
                onClick={handleConfirmDeposit}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                ✓ Confirmar Depósito
              </button>
              <button
                onClick={() => setDepositInfo(null)}
                className="flex-1 bg-gray-700 hover:bg-gray-600"
              >
                Cancelar
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
