import { useState, useEffect } from "react";
import Link from "next/link";
import api from "../lib/api";

export default function Admin() {
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState("");
  const [valor, setValor] = useState("");
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    loadAdminData();
  }, []);

  const loadAdminData = async () => {
    try {
      const [statsRes, usersRes] = await Promise.all([
        api.get("/admin/stats"),
        api.get("/admin/users")
      ]);

      setStats(statsRes.data);
      setUsers(usersRes.data.users);
    } catch (error) {
      alert("Erro ao carregar dados: " + error.response?.data?.error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateSaldo = async (e) => {
    e.preventDefault();
    setUpdating(true);

    try {
      await api.post("/admin/user/saldo", {
        email,
        valor: parseFloat(valor)
      });

      alert("Saldo atualizado com sucesso!");
      setEmail("");
      setValor("");
      loadAdminData();
    } catch (error) {
      alert("Erro: " + error.response?.data?.error);
    } finally {
      setUpdating(false);
    }
  };

  return (
    <div className="min-h-screen bg-dark">
      <header className="bg-darker p-4 border-b border-gray-700">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <Link href="/">
            <h1 className="text-3xl font-bold text-primary cursor-pointer">BYC.BET</h1>
          </Link>
          <Link href="/">
            <button className="bg-gray-700 hover:bg-gray-600">← Voltar</button>
          </Link>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-4 py-12">
        <h2 className="text-3xl font-bold mb-8">👑 Painel Administrativo</h2>

        {loading ? (
          <p className="text-center text-gray-400">Carregando...</p>
        ) : (
          <>
            {/* Estatísticas */}
            {stats && (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                <div className="bg-darker p-6 rounded-lg">
                  <p className="text-gray-400 mb-2">Total de Usuários</p>
                  <h3 className="text-3xl font-bold text-neon">{stats.totalUsers}</h3>
                </div>

                <div className="bg-darker p-6 rounded-lg">
                  <p className="text-gray-400 mb-2">Saldo Total</p>
                  <h3 className="text-3xl font-bold text-neon">
                    R$ {stats.totalSaldo?.toFixed(2) || "0.00"}
                  </h3>
                </div>

                <div className="bg-darker p-6 rounded-lg">
                  <p className="text-gray-400 mb-2">Depósitos</p>
                  <h3 className="text-3xl font-bold text-green-500">
                    R$ {stats.totalDepositos?.toFixed(2) || "0.00"}
                  </h3>
                </div>

                <div className="bg-darker p-6 rounded-lg">
                  <p className="text-gray-400 mb-2">Lucro</p>
                  <h3 className="text-3xl font-bold text-primary">
                    R$ {stats.lucro?.toFixed(2) || "0.00"}
                  </h3>
                </div>
              </div>
            )}

            {/* Alterar Saldo */}
            <div className="bg-darker p-6 rounded-lg mb-8">
              <h3 className="text-xl font-bold mb-4">💰 Alterar Saldo de Usuário</h3>

              <form onSubmit={handleUpdateSaldo} className="flex gap-4">
                <input
                  type="email"
                  placeholder="Email do usuário"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="flex-1"
                />

                <input
                  type="number"
                  step="0.01"
                  placeholder="Valor (positivo ou negativo)"
                  value={valor}
                  onChange={(e) => setValor(e.target.value)}
                  required
                  className="flex-1"
                />

                <button
                  type="submit"
                  disabled={updating}
                  className="px-6"
                >
                  {updating ? "Atualizando..." : "Atualizar"}
                </button>
              </form>
            </div>

            {/* Lista de Usuários */}
            <div className="bg-darker p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">👥 Usuários ({users.length})</h3>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-700">
                      <th className="text-left p-3">Email</th>
                      <th className="text-left p-3">Saldo</th>
                      <th className="text-left p-3">Ganhos Afiliado</th>
                      <th className="text-left p-3">Cadastrado em</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((user, idx) => (
                      <tr key={idx} className="border-b border-gray-700 hover:bg-darker">
                        <td className="p-3">{user.email}</td>
                        <td className="p-3 text-neon">R$ {user.saldo?.toFixed(2) || "0.00"}</td>
                        <td className="p-3 text-green-500">
                          R$ {user.ganhosAfiliado?.toFixed(2) || "0.00"}
                        </td>
                        <td className="p-3 text-gray-400 text-sm">
                          {new Date(user.createdAt).toLocaleDateString("pt-BR")}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
