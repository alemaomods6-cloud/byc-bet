import { useState, useEffect } from "react";
import Link from "next/link";
import api from "../../lib/api";

export default function Aviator() {
  const [user, setUser] = useState(null);
  const [multiplicador, setMultiplicador] = useState(1);
  const [gameActive, setGameActive] = useState(false);
  const [loading, setLoading] = useState(false);
  const [crashPoint, setCrashPoint] = useState(null);
  const [betPlaced, setBetPlaced] = useState(false);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const response = await api.get("/user/profile");
      setUser(response.data);
    } catch (error) {
      console.error("Erro ao carregar usuário:", error);
    }
  };

  const startGame = async () => {
    setLoading(true);
    try {
      const response = await api.get("/games/aviator/start");
      setCrashPoint(response.data.crash);
      setMultiplicador(1);
      setGameActive(true);
      setBetPlaced(true);

      // Simular o crescimento do multiplicador
      let current = 1;
      const interval = setInterval(() => {
        current += 0.1;
        setMultiplicador(parseFloat(current.toFixed(2)));

        if (current >= response.data.crash) {
          clearInterval(interval);
          alert(`💥 Crash em ${response.data.crash}x!`);
          setGameActive(false);
          setBetPlaced(false);
        }
      }, 100);
    } catch (error) {
      alert("Erro: " + error.response?.data?.error);
    } finally {
      setLoading(false);
    }
  };

  const cashout = async () => {
    setLoading(true);
    try {
      const response = await api.post("/games/aviator/cashout", {
        multiplicador
      });

      alert(`✓ Você ganhou R$ ${response.data.ganho.toFixed(2)}!`);
      setUser(response.data.user);
      setGameActive(false);
      setBetPlaced(false);
      setCrashPoint(null);
      setMultiplicador(1);
    } catch (error) {
      alert("Erro: " + error.response?.data?.error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-dark">
      <header className="bg-darker p-4 border-b border-gray-700">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <Link href="/">
            <h1 className="text-3xl font-bold text-primary cursor-pointer">BYC.BET</h1>
          </Link>
          <Link href="/">
            <button className="bg-gray-700 hover:bg-gray-600">← Voltar</button>
          </Link>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-4 py-12">
        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold mb-2">✈️ Aviator</h2>
          <p className="text-gray-400">Saia antes do crash e ganhe o multiplicador</p>
        </div>

        {user && (
          <div className="bg-darker p-4 rounded-lg mb-8 text-center">
            <p className="text-gray-400">Saldo</p>
            <h3 className="text-3xl font-bold text-neon">R$ {user.saldo?.toFixed(2) || "0.00"}</h3>
          </div>
        )}

        <div className="bg-darker p-12 rounded-lg text-center">
          <div className="mb-8">
            <p className="text-gray-400 mb-4">Multiplicador Atual</p>
            <div className="text-7xl font-bold text-neon mb-4">
              {multiplicador.toFixed(2)}x
            </div>
            {betPlaced && (
              <p className="text-gray-400">
                Ganho potencial: R$ {(multiplicador * 10).toFixed(2)}
              </p>
            )}
          </div>

          {!gameActive && !betPlaced ? (
            <div>
              <p className="text-gray-300 mb-6">Aposta: R$ 10,00</p>
              <button
                onClick={startGame}
                disabled={loading || !user || user.saldo < 10}
                className="px-12 py-4 text-xl"
              >
                {loading ? "Iniciando..." : "Começar Jogo"}
              </button>
            </div>
          ) : gameActive && betPlaced ? (
            <button
              onClick={cashout}
              disabled={loading}
              className="px-12 py-4 text-xl bg-green-600 hover:bg-green-700"
            >
              {loading ? "Processando..." : "💰 Sacar Agora"}
            </button>
          ) : null}
        </div>

        {/* Info */}
        <div className="bg-darker p-6 rounded-lg mt-8">
          <h3 className="text-xl font-bold mb-4">📖 Como Jogar</h3>
          <ul className="space-y-3 text-gray-300">
            <li className="flex items-start gap-3">
              <span className="text-neon font-bold">1.</span>
              <span>Clique em "Começar Jogo" para fazer uma aposta de R$ 10,00</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-neon font-bold">2.</span>
              <span>O multiplicador começa a crescer</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-neon font-bold">3.</span>
              <span>Clique em "Sacar" antes do crash para ganhar</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-neon font-bold">4.</span>
              <span>Se não sacar a tempo, perde a aposta</span>
            </li>
          </ul>
        </div>
      </main>
    </div>
  );
}
