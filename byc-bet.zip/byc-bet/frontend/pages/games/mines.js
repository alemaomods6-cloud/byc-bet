import { useState, useEffect } from "react";
import Link from "next/link";
import api from "../../lib/api";

export default function Mines() {
  const [user, setUser] = useState(null);
  const [grid, setGrid] = useState([]);
  const [revealed, setRevealed] = useState([]);
  const [multiplicador, setMultiplicador] = useState(1);
  const [gameActive, setGameActive] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const response = await api.get("/user/profile");
      setUser(response.data);
    } catch (error) {
      console.error("Erro ao carregar usuário:", error);
    }
  };

  const startGame = async () => {
    setLoading(true);
    try {
      const response = await api.post("/games/mines/start", { bombas: 3 });
      setGrid(response.data.grid);
      setRevealed([]);
      setMultiplicador(1);
      setGameActive(true);
      setUser(prev => ({ ...prev, saldo: response.data.saldo }));
    } catch (error) {
      alert("Erro: " + error.response?.data?.error);
    } finally {
      setLoading(false);
    }
  };

  const clickCell = (index) => {
    if (revealed.includes(index) || !gameActive) return;

    if (grid[index] === 1) {
      alert("💥 Você perdeu!");
      setGameActive(false);
      setGrid([]);
      return;
    }

    const newRevealed = [...revealed, index];
    setRevealed(newRevealed);

    const newMultiplicador = 1 + newRevealed.length * 0.5;
    setMultiplicador(newMultiplicador);
  };

  const cashout = async () => {
    setLoading(true);
    try {
      const ganho = multiplicador * 10;
      const response = await api.post("/games/mines/cashout", { ganho });

      alert(`✓ Você ganhou R$ ${ganho.toFixed(2)}!`);
      setUser(response.data);
      setGameActive(false);
      setGrid([]);
      setRevealed([]);
      setMultiplicador(1);
    } catch (error) {
      alert("Erro: " + error.response?.data?.error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-dark">
      <header className="bg-darker p-4 border-b border-gray-700">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <Link href="/">
            <h1 className="text-3xl font-bold text-primary cursor-pointer">BYC.BET</h1>
          </Link>
          <Link href="/">
            <button className="bg-gray-700 hover:bg-gray-600">← Voltar</button>
          </Link>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-4 py-12">
        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold mb-2">💣 Mines</h2>
          <p className="text-gray-400">Clique nos quadrados seguros e ganhe multiplicadores</p>
        </div>

        {user && (
          <div className="bg-darker p-4 rounded-lg mb-8 text-center">
            <p className="text-gray-400">Saldo</p>
            <h3 className="text-3xl font-bold text-neon">R$ {user.saldo?.toFixed(2) || "0.00"}</h3>
          </div>
        )}

        <div className="bg-darker p-8 rounded-lg">
          {!gameActive && grid.length === 0 ? (
            <div className="text-center">
              <p className="text-gray-300 mb-6">Aposta: R$ 10,00</p>
              <button
                onClick={startGame}
                disabled={loading || !user || user.saldo < 10}
                className="px-8 py-4 text-lg"
              >
                {loading ? "Iniciando..." : "Começar Jogo"}
              </button>
            </div>
          ) : (
            <>
              <div className="mb-8">
                <div className="grid grid-cols-5 gap-3 mb-8">
                  {grid.map((cell, idx) => (
                    <button
                      key={idx}
                      onClick={() => clickCell(idx)}
                      disabled={!gameActive || revealed.includes(idx)}
                      className={`w-16 h-16 rounded-lg font-bold text-2xl transition ${
                        revealed.includes(idx)
                          ? "bg-neon text-dark"
                          : "bg-gray-700 hover:bg-gray-600"
                      }`}
                    >
                      {revealed.includes(idx) ? "💎" : ""}
                    </button>
                  ))}
                </div>

                <div className="text-center">
                  <p className="text-gray-400 mb-2">Multiplicador</p>
                  <h3 className="text-4xl font-bold text-neon">
                    {multiplicador.toFixed(2)}x
                  </h3>
                  <p className="text-gray-400 text-sm mt-2">
                    Ganho potencial: R$ {(multiplicador * 10).toFixed(2)}
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <button
                  onClick={cashout}
                  disabled={loading || revealed.length === 0}
                  className="flex-1 bg-green-600 hover:bg-green-700 py-4 text-lg"
                >
                  {loading ? "Processando..." : "💰 Sacar"}
                </button>
                <button
                  onClick={() => {
                    setGameActive(false);
                    setGrid([]);
                    setRevealed([]);
                    setMultiplicador(1);
                  }}
                  className="flex-1 bg-red-600 hover:bg-red-700 py-4 text-lg"
                >
                  Desistir
                </button>
              </div>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
