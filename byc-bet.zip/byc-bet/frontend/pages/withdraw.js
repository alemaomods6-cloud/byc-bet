import { useState, useEffect } from "react";
import Link from "next/link";
import api from "../lib/api";

export default function Withdraw() {
  const [valor, setValor] = useState("");
  const [pix, setPix] = useState("");
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState(null);
  const [withdrawHistory, setWithdrawHistory] = useState([]);

  useEffect(() => {
    loadUser();
    loadWithdrawHistory();
  }, []);

  const loadUser = async () => {
    try {
      const response = await api.get("/user/profile");
      setUser(response.data);
    } catch (error) {
      console.error("Erro ao carregar usuário:", error);
    }
  };

  const loadWithdrawHistory = async () => {
    try {
      const response = await api.get("/payments/withdraw/history");
      setWithdrawHistory(response.data.withdraws);
    } catch (error) {
      console.error("Erro ao carregar histórico:", error);
    }
  };

  const handleWithdraw = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await api.post("/payments/withdraw/request", {
        valor: parseFloat(valor),
        pix
      });

      alert("Saque solicitado com sucesso!");
      setValor("");
      setPix("");
      loadUser();
      loadWithdrawHistory();
    } catch (error) {
      alert("Erro: " + error.response?.data?.error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-dark">
      <header className="bg-darker p-4 border-b border-gray-700">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <Link href="/">
            <h1 className="text-3xl font-bold text-primary cursor-pointer">BYC.BET</h1>
          </Link>
          <Link href="/">
            <button className="bg-gray-700 hover:bg-gray-600">← Voltar</button>
          </Link>
        </div>
      </header>

      <main className="max-w-2xl mx-auto p-4 py-12">
        <h2 className="text-3xl font-bold mb-8">Sacar</h2>

        {user && (
          <div className="bg-darker p-4 rounded-lg mb-8">
            <p className="text-gray-400">Saldo Disponível</p>
            <h3 className="text-3xl font-bold text-neon">R$ {user.saldo?.toFixed(2) || "0.00"}</h3>
          </div>
        )}

        <form onSubmit={handleWithdraw} className="bg-darker p-6 rounded-lg mb-8">
          <label className="block mb-4">
            <span className="text-gray-300 mb-2 block">Valor do Saque (R$)</span>
            <input
              type="number"
              step="0.01"
              min="1"
              placeholder="Digite o valor"
              value={valor}
              onChange={(e) => setValor(e.target.value)}
              required
            />
          </label>

          <label className="block mb-6">
            <span className="text-gray-300 mb-2 block">Chave PIX</span>
            <input
              type="text"
              placeholder="Digite sua chave PIX (email, CPF, telefone ou aleatória)"
              value={pix}
              onChange={(e) => setPix(e.target.value)}
              required
            />
          </label>

          <button
            type="submit"
            disabled={loading}
            className="w-full"
          >
            {loading ? "Processando..." : "Solicitar Saque"}
          </button>
        </form>

        {withdrawHistory.length > 0 && (
          <div className="bg-darker p-6 rounded-lg">
            <h3 className="text-xl font-bold mb-4">Histórico de Saques</h3>
            <div className="space-y-4">
              {withdrawHistory.map((w, idx) => (
                <div key={idx} className="border border-gray-700 p-4 rounded">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-bold">R$ {w.valor?.toFixed(2)}</span>
                    <span className={`px-3 py-1 rounded text-sm ${
                      w.status === "paid" ? "bg-green-600" : "bg-yellow-600"
                    }`}>
                      {w.status === "paid" ? "✓ Pago" : "⏳ Pendente"}
                    </span>
                  </div>
                  <p className="text-gray-400 text-sm">{w.pix}</p>
                  <p className="text-gray-500 text-sm">
                    {new Date(w.date).toLocaleDateString("pt-BR")}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
