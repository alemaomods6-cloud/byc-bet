/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: '#8a2be2',
        dark: '#0d0d0d',
        darker: '#1a1a1a',
        neon: '#00ff99',
      }
    },
  },
  plugins: [],
}
