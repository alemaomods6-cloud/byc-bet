const crypto = require("crypto");

/**
 * Gera um número aleatório criptograficamente seguro entre 0 e 1
 * @returns {number} Número aleatório entre 0 e 1
 */
function rng() {
  return crypto.randomBytes(4).readUInt32BE() / 4294967295;
}

/**
 * Gera um grid para o jogo Mines
 * @param {number} bombas - Quantidade de bombas (padrão: 3)
 * @returns {array} Array com 25 posições (0 = seguro, 1 = bomba)
 */
function gerarGridMines(bombas = 3) {
  let grid = Array(25).fill(0);
  let placed = 0;

  while (placed < bombas) {
    let i = Math.floor(rng() * 25);
    if (!grid[i]) {
      grid[i] = 1;
      placed++;
    }
  }

  return grid;
}

/**
 * Calcula o ponto de crash para o Aviator
 * @returns {number} Multiplicador de crash
 */
function crashPoint() {
  const r = rng();
  return Math.floor((100 / (1 - r))) / 100;
}

module.exports = {
  rng,
  gerarGridMines,
  crashPoint
};
