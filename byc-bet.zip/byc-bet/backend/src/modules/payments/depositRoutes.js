const express = require("express");
const User = require("../../models/User");
const { authMiddleware } = require("../auth/authMiddleware");

const router = express.Router();

const PIX_KEY = "6021408@vakinha.com.br";
const PIX_RECEIVER = "BYC LTDA";
const MIN_DEPOSIT = 1;
const MAX_DEPOSIT = 500;

/**
 * POST /payments/deposit/request
 * Solicitar depósito via PIX
 */
router.post("/deposit/request", authMiddleware, async (req, res) => {
  try {
    const { valor } = req.body;

    if (!valor || valor < MIN_DEPOSIT || valor > MAX_DEPOSIT) {
      return res.status(400).json({
        error: `Valor deve estar entre R$${MIN_DEPOSIT} e R$${MAX_DEPOSIT}`
      });
    }

    const user = await User.findById(req.user.id);

    // Adicionar depósito ao histórico
    user.deposits.push({
      valor,
      status: "pending"
    });

    await user.save();

    res.json({
      status: "pending",
      pix: PIX_KEY,
      recebedor: PIX_RECEIVER,
      valor,
      depositId: user.deposits[user.deposits.length - 1]._id
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * POST /payments/deposit/confirm
 * Confirmar depósito (simulado)
 */
router.post("/deposit/confirm", authMiddleware, async (req, res) => {
  try {
    const { depositId, valor } = req.body;

    const user = await User.findById(req.user.id);
    const deposit = user.deposits.find(d => d._id.toString() === depositId);

    if (!deposit) {
      return res.status(404).json({ error: "Depósito não encontrado" });
    }

    // Adicionar saldo
    user.saldo += valor;
    deposit.status = "confirmed";

    // Verificar se tem afiliado e dar comissão
    if (user.referredBy) {
      const afiliado = await User.findOne({ referralCode: user.referredBy });
      if (afiliado) {
        const comissao = valor * 0.05; // 5%
        afiliado.saldo += comissao;
        afiliado.ganhosAfiliado += comissao;
        await afiliado.save();
      }
    }

    await user.save();

    res.json({
      message: "Depósito confirmado",
      saldo: user.saldo
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /payments/deposit/history
 * Histórico de depósitos
 */
router.get("/deposit/history", authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);

    res.json({
      deposits: user.deposits
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
