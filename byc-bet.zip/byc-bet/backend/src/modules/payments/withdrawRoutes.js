const express = require("express");
const User = require("../../models/User");
const { authMiddleware } = require("../auth/authMiddleware");

const router = express.Router();

/**
 * POST /payments/withdraw/request
 * Solicitar saque via PIX
 */
router.post("/withdraw/request", authMiddleware, async (req, res) => {
  try {
    const { valor, pix } = req.body;

    if (!valor || valor <= 0) {
      return res.status(400).json({ error: "Valor inválido" });
    }

    if (!pix) {
      return res.status(400).json({ error: "Chave PIX é obrigatória" });
    }

    const user = await User.findById(req.user.id);

    if (valor > user.saldo) {
      return res.status(400).json({ error: "Saldo insuficiente" });
    }

    // Descontar saldo
    user.saldo -= valor;

    // Adicionar saque ao histórico
    user.withdraws.push({
      valor,
      pix,
      status: "pending"
    });

    await user.save();

    res.json({
      message: "Saque solicitado com sucesso",
      withdrawId: user.withdraws[user.withdraws.length - 1]._id,
      saldo: user.saldo
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /payments/withdraw/history
 * Histórico de saques
 */
router.get("/withdraw/history", authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);

    res.json({
      withdraws: user.withdraws
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
