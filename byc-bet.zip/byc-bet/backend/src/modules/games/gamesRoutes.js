const express = require("express");
const User = require("../../models/User");
const { authMiddleware } = require("../auth/authMiddleware");
const { gerarGridMines, crashPoint } = require("../../utils/rng");

const router = express.Router();

const MINES_BET = 10;

/**
 * POST /games/mines/start
 * Iniciar jogo de Mines
 */
router.post("/mines/start", authMiddleware, async (req, res) => {
  try {
    const { bombas = 3 } = req.body;

    const user = await User.findById(req.user.id);

    if (user.saldo < MINES_BET) {
      return res.status(400).json({ error: "Saldo insuficiente" });
    }

    // Descontar aposta
    user.saldo -= MINES_BET;
    await user.save();

    // Gerar grid
    const grid = gerarGridMines(bombas);

    res.json({
      grid,
      bet: MINES_BET,
      multiplicador: 1,
      saldo: user.saldo
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * POST /games/mines/cashout
 * Sacar ganhos do Mines
 */
router.post("/mines/cashout", authMiddleware, async (req, res) => {
  try {
    const { ganho } = req.body;

    if (!ganho || ganho <= 0) {
      return res.status(400).json({ error: "Ganho inválido" });
    }

    const user = await User.findById(req.user.id);
    user.saldo += ganho;
    await user.save();

    res.json({
      message: "Ganho creditado",
      saldo: user.saldo,
      ganho
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /games/aviator/start
 * Iniciar jogo de Aviator (Crash)
 */
router.get("/aviator/start", authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);

    if (user.saldo < MINES_BET) {
      return res.status(400).json({ error: "Saldo insuficiente" });
    }

    // Calcular ponto de crash
    const crash = crashPoint();

    res.json({
      crash,
      bet: MINES_BET,
      multiplicador: 1
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * POST /games/aviator/cashout
 * Sacar ganhos do Aviator
 */
router.post("/aviator/cashout", authMiddleware, async (req, res) => {
  try {
    const { multiplicador } = req.body;

    if (!multiplicador || multiplicador < 1) {
      return res.status(400).json({ error: "Multiplicador inválido" });
    }

    const user = await User.findById(req.user.id);
    const ganho = MINES_BET * multiplicador;

    user.saldo += ganho;
    await user.save();

    res.json({
      message: "Ganho creditado",
      saldo: user.saldo,
      ganho,
      multiplicador
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
