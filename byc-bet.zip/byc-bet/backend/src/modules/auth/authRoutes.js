const express = require("express");
const jwt = require("jsonwebtoken");
const User = require("../../models/User");
const { gerarCodigo } = require("../user/userUtils");

const router = express.Router();

/**
 * POST /auth/login
 * Login com email (cria usuário se não existir)
 */
router.post("/login", async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ error: "Email é obrigatório" });
    }

    let user = await User.findOne({ email });

    if (!user) {
      user = await User.create({
        email,
        referralCode: gerarCodigo()
      });
    }

    const token = jwt.sign(
      { 
        id: user._id, 
        email: user.email, 
        admin: email === "admin@byc.com" 
      },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.json({
      token,
      user: {
        id: user._id,
        email: user.email,
        saldo: user.saldo,
        referralCode: user.referralCode,
        ganhosAfiliado: user.ganhosAfiliado
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * POST /auth/register
 * Registro com código de referência
 */
router.post("/register", async (req, res) => {
  try {
    const { email, ref } = req.body;

    if (!email) {
      return res.status(400).json({ error: "Email é obrigatório" });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: "Email já cadastrado" });
    }

    const novo = await User.create({
      email,
      referralCode: gerarCodigo(),
      referredBy: ref || null
    });

    const token = jwt.sign(
      { id: novo._id, email: novo.email, admin: false },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.json({
      token,
      user: {
        id: novo._id,
        email: novo.email,
        saldo: novo.saldo,
        referralCode: novo.referralCode
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
