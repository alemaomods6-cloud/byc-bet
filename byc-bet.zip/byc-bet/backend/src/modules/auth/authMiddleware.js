const jwt = require("jsonwebtoken");

/**
 * Middleware de autenticação JWT
 */
function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.split(" ")[1];

  if (!token) {
    return res.status(401).json({ error: "Token não fornecido" });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ error: "Token inválido" });
  }
}

/**
 * Middleware para verificar se é admin
 */
function adminMiddleware(req, res, next) {
  if (!req.user || !req.user.admin) {
    return res.status(403).json({ error: "Acesso negado. Admin requerido." });
  }
  next();
}

module.exports = {
  authMiddleware,
  adminMiddleware
};
