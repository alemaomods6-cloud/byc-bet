const express = require("express");
const User = require("../../models/User");
const { authMiddleware, adminMiddleware } = require("../auth/authMiddleware");

const router = express.Router();

/**
 * GET /admin/stats
 * Obter estatísticas do sistema
 */
router.get("/stats", authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const users = await User.find();
    const totalUsers = users.length;
    const totalSaldo = users.reduce((acc, u) => acc + u.saldo, 0);
    const totalGanhosAfiliados = users.reduce((acc, u) => acc + u.ganhosAfiliado, 0);

    // Calcular lucro (depósitos - saques)
    let totalDepositos = 0;
    let totalSaques = 0;

    users.forEach(user => {
      user.deposits.forEach(d => {
        if (d.status === "confirmed") totalDepositos += d.valor;
      });
      user.withdraws.forEach(w => {
        if (w.status === "paid") totalSaques += w.valor;
      });
    });

    const lucro = totalDepositos - totalSaques;

    res.json({
      totalUsers,
      totalSaldo,
      totalGanhosAfiliados,
      totalDepositos,
      totalSaques,
      lucro
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /admin/users
 * Listar todos os usuários
 */
router.get("/users", authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const users = await User.find().select("-withdraws -deposits");

    res.json({
      users: users.map(u => ({
        id: u._id,
        email: u.email,
        saldo: u.saldo,
        referralCode: u.referralCode,
        ganhosAfiliado: u.ganhosAfiliado,
        createdAt: u.createdAt
      }))
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * POST /admin/user/saldo
 * Alterar saldo de um usuário
 */
router.post("/user/saldo", authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const { email, valor } = req.body;

    if (!email || valor === undefined) {
      return res.status(400).json({ error: "Email e valor são obrigatórios" });
    }

    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ error: "Usuário não encontrado" });
    }

    user.saldo += valor;
    await user.save();

    res.json({
      message: "Saldo alterado",
      user: {
        email: user.email,
        saldo: user.saldo
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /admin/user/:email
 * Obter detalhes de um usuário
 */
router.get("/user/:email", authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const { email } = req.params;

    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ error: "Usuário não encontrado" });
    }

    res.json({
      id: user._id,
      email: user.email,
      saldo: user.saldo,
      referralCode: user.referralCode,
      ganhosAfiliado: user.ganhosAfiliado,
      deposits: user.deposits,
      withdraws: user.withdraws,
      createdAt: user.createdAt
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
