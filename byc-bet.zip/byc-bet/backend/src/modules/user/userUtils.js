/**
 * Gera um código de afiliado único
 * @returns {string} Código alfanumérico de 6 caracteres
 */
function gerarCodigo() {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

module.exports = {
  gerarCodigo
};
