const express = require("express");
const User = require("../../models/User");
const { authMiddleware } = require("../auth/authMiddleware");

const router = express.Router();

/**
 * GET /user/profile
 * Obter perfil do usuário autenticado
 */
router.get("/profile", authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);

    if (!user) {
      return res.status(404).json({ error: "Usuário não encontrado" });
    }

    res.json({
      id: user._id,
      email: user.email,
      saldo: user.saldo,
      referralCode: user.referralCode,
      ganhosAfiliado: user.ganhosAfiliado,
      createdAt: user.createdAt
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /user/referral-stats
 * Obter estatísticas de afiliado
 */
router.get("/referral-stats", authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    const referredUsers = await User.find({ referredBy: user.referralCode });

    res.json({
      referralCode: user.referralCode,
      referralLink: `${process.env.FRONTEND_URL}/register?ref=${user.referralCode}`,
      ganhosAfiliado: user.ganhosAfiliado,
      referredCount: referredUsers.length,
      referredUsers: referredUsers.map(u => ({
        email: u.email,
        saldo: u.saldo,
        createdAt: u.createdAt
      }))
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
