require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

// Importar rotas
const authRoutes = require("./modules/auth/authRoutes");
const userRoutes = require("./modules/user/userRoutes");
const depositRoutes = require("./modules/payments/depositRoutes");
const withdrawRoutes = require("./modules/payments/withdrawRoutes");
const gamesRoutes = require("./modules/games/gamesRoutes");
const adminRoutes = require("./modules/admin/adminRoutes");

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// Conectar ao MongoDB
mongoose.connect(process.env.MONGO_URL)
  .then(() => console.log("✅ Conectado ao MongoDB"))
  .catch(err => console.error("❌ Erro ao conectar MongoDB:", err));

// Rotas
app.use("/auth", authRoutes);
app.use("/user", userRoutes);
app.use("/payments", depositRoutes);
app.use("/payments", withdrawRoutes);
app.use("/games", gamesRoutes);
app.use("/admin", adminRoutes);

// Health check
app.get("/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date() });
});

// Tratamento de erros
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Erro interno do servidor" });
});

// Iniciar servidor
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`🚀 Backend BYC.BET rodando na porta ${PORT}`);
});

module.exports = app;
