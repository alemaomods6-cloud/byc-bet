const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true
  },
  saldo: {
    type: Number,
    default: 0
  },
  referralCode: {
    type: String,
    unique: true
  },
  referredBy: {
    type: String,
    default: null
  },
  ganhosAfiliado: {
    type: Number,
    default: 0
  },
  withdraws: [
    {
      valor: Number,
      pix: String,
      status: {
        type: String,
        enum: ["pending", "paid", "rejected"],
        default: "pending"
      },
      date: {
        type: Date,
        default: Date.now
      }
    }
  ],
  deposits: [
    {
      valor: Number,
      status: {
        type: String,
        enum: ["pending", "confirmed"],
        default: "pending"
      },
      date: {
        type: Date,
        default: Date.now
      }
    }
  ],
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model("User", UserSchema);
