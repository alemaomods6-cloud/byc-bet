# 🎰 BYC.BET - Plataforma de Apostas e Cassino Online

Plataforma completa de apostas esportivas e cassino online com jogos como **Mines** e **Aviator**, sistema de afiliados, depósitos via PIX e painel administrativo.

## 🚀 Características

- ✅ **Autenticação JWT** - Login seguro com tokens
- ✅ **Mines** - Jogo de multiplicador com bombas
- ✅ **Aviator** - Jogo de crash com multiplicador dinâmico
- ✅ **Sistema de Afiliados** - Ganhe 5% de comissão em depósitos
- ✅ **Depósitos via PIX** - Integração simulada
- ✅ **Saques** - Sistema de saque com histórico
- ✅ **Painel Admin** - Controle total do sistema
- ✅ **RNG Criptográfico** - Números aleatórios seguros
- ✅ **Responsivo** - Funciona em desktop e mobile

## 📁 Estrutura do Projeto

```
byc-bet/
├── backend/
│   ├── src/
│   │   ├── modules/
│   │   │   ├── auth/
│   │   │   ├── user/
│   │   │   ├── games/
│   │   │   ├── payments/
│   │   │   └── admin/
│   │   ├── utils/
│   │   └── app.js
│   ├── models/
│   ├── package.json
│   ├── .env
│   └── Dockerfile
├── frontend/
│   ├── pages/
│   ├── components/
│   ├── lib/
│   ├── styles/
│   ├── package.json
│   ├── .env.local
│   └── next.config.js
├── docker-compose.yml
└── README.md
```

## 🛠️ Instalação

### Pré-requisitos

- Node.js 18+
- MongoDB (local ou Atlas)
- npm ou yarn

### Backend

```bash
cd backend
npm install
npm start
```

O backend rodará em `http://localhost:3001`

### Frontend

```bash
cd frontend
npm install
npm run dev
```

O frontend rodará em `http://localhost:3000`

### Com Docker

```bash
docker-compose up
```

## 📚 API Endpoints

### Autenticação
- `POST /auth/login` - Login com email
- `POST /auth/register` - Registro com código de referência

### Usuário
- `GET /user/profile` - Perfil do usuário
- `GET /user/referral-stats` - Estatísticas de afiliado

### Pagamentos
- `POST /payments/deposit/request` - Solicitar depósito
- `POST /payments/deposit/confirm` - Confirmar depósito
- `GET /payments/deposit/history` - Histórico de depósitos
- `POST /payments/withdraw/request` - Solicitar saque
- `GET /payments/withdraw/history` - Histórico de saques

### Jogos
- `POST /games/mines/start` - Iniciar Mines
- `POST /games/mines/cashout` - Sacar ganhos do Mines
- `GET /games/aviator/start` - Iniciar Aviator
- `POST /games/aviator/cashout` - Sacar ganhos do Aviator

### Admin
- `GET /admin/stats` - Estatísticas do sistema
- `GET /admin/users` - Listar usuários
- `POST /admin/user/saldo` - Alterar saldo
- `GET /admin/user/:email` - Detalhes do usuário

## 🔐 Segurança

- ✅ JWT com expiração
- ✅ RNG criptográfico para jogos
- ✅ Validação de dados
- ✅ Proteção contra saldo negativo
- ✅ Middleware de autenticação

## 💰 Configuração PIX

**Chave PIX:** 6021408@vakinha.com.br  
**Recebedor:** BYC LTDA

## 🎮 Como Jogar

### Mines
1. Clique em "Começar" para apostar R$ 10
2. Clique nos quadrados seguros
3. Cada quadrado seguro aumenta o multiplicador
4. Clique em "Sacar" para ganhar ou "Desistir"

### Aviator
1. Clique em "Começar" para apostar R$ 10
2. O multiplicador cresce automaticamente
3. Clique em "Sacar" antes do crash
4. Se não sacar a tempo, perde a aposta

## 🧑‍💼 Painel Admin

Acesse em `/admin` com email `admin@byc.com`

**Funcionalidades:**
- Ver estatísticas (usuários, saldo, lucro)
- Listar todos os usuários
- Alterar saldo de usuários
- Ver histórico de depósitos e saques

## 🌐 Deploy

### Frontend (Vercel)
```bash
vercel deploy
```

### Backend (Railway/Render)
```bash
# Variáveis de ambiente
MONGO_URL=mongodb+srv://...
JWT_SECRET=seu_segredo
PORT=3001
```

## 📝 Variáveis de Ambiente

### Backend (.env)
```
PORT=3001
MONGO_URL=mongodb://127.0.0.1:27017/bycbet
JWT_SECRET=BYC_SUPER_SECRET_KEY_2024
NODE_ENV=development
```

### Frontend (.env.local)
```
NEXT_PUBLIC_API_URL=http://localhost:3001
NEXT_PUBLIC_FIREBASE_API_KEY=...
```

## 🤝 Sistema de Afiliados

- Cada usuário tem um código único
- Compartilhe o link: `byc.bet/register?ref=SEU_CODIGO`
- Ganhe 5% de comissão em cada depósito do indicado
- Os ganhos são creditados automaticamente

## ⚠️ Importante

Este é um projeto de demonstração. Para uso em produção:

- [ ] Implementar HTTPS obrigatório
- [ ] Usar API real de PIX (Mercado Pago, Efí, etc.)
- [ ] Implementar KYC (verificação de identidade)
- [ ] Sistema antifraude
- [ ] Conformidade legal (Lei das Apostas no Brasil)
- [ ] Termos de Serviço e Privacidade

## 📞 Suporte

Para dúvidas ou problemas, abra uma issue no repositório.

## 📄 Licença

MIT License - Veja LICENSE para detalhes

---

**Desenvolvido com ❤️ para BYC.BET**
